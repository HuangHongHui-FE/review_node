/*
    基础配置
      baseUrl 当前程序请求的主域名
      myAppid 到小程序中绑定获取到的 myAppid
*/
var baseUrl = 'https://poststudent.mumudev.top/api'
var myAppid = '644cfa8f57c9893990e748c53720035c54a39a00appId'


// 1、创建一个闭包，返回出一个对象赋值给一个全局变量
//    闭包：防止变量冲突
;
var mu = (function() {

  // 3、自己封装一个请求对象，会自动带上 appid 和 token
  function request(options) {
    // 设置请求头，带上 appid
    var headers = {
      'my-appid': myAppid
    }
    // 查看本地是否有 token，有的话就带上token
    var token = window.localStorage.getItem('m_token')
    if (token) {
      headers['token'] = token
    }

    // 封装 jQuery 的 ajax 请求
    $.ajax({
      url: baseUrl + options.path,
      type: options.type,
      data: options.data || {},
      headers: headers,
      success: function(res, status, xhr) {
        // 获取响应头中的 token，如果存在就缓存到本地
        var token = xhr.getResponseHeader('token')
        if (token) {
          window.localStorage.setItem('m_token', token)
        }
        // 请求成功，调用回调函数
        options.callBack && options.callBack(res)
      },
      error: function(e) {
        // alert('请求出错了,详情看控制台')
        console.log(e)
      }
    })
  }


  // 2、创建一个对象用于导出之后需要使用到的方法或者变量
  var obj = {
    // 2.1、获取到一个回调的 url
    config: function() {
      var token = window.localStorage.getItem('m_token')
      return encodeURIComponent('http://poststudent.mumudev.top/api/login_company?myAppid=' + myAppid + '&token=' + token)
      //return encodeURIComponent('http://hjswecat.yyuebd.com/api/company/studentLogin?myLogin=' + myLogin + '&myAppid=' + myAppid + '&token=' + token)
    },
    // 2.2、post请求
    post: function(path, data, callBack, options) {
      if (typeof options !== 'object') {
        options = {}
      }
      options['path'] = path
      options['data'] = data
      options['callBack'] = callBack
      options['type'] = 'post'
      request(options)
    },
    // 2.3、get请求
    get: function(path, data, callBack, options) {
      if (typeof options !== 'object') {
        options = {}
      }
      options['path'] = path
      options['data'] = data
      options['callBack'] = callBack
      options['type'] = 'get'
      request(options)
    }
  }

  return obj
})()